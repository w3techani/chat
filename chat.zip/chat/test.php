<?php
file_put_contents('/var/www/html/test/chat/list.txt', 'test1', FILE_APPEND);
?>
