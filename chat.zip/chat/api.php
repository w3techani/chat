<?php

require_once("php-socket.php");
//$chatHandler1 = new ChatHandler();
//$chat_box_message = 'Hey';
$chatHandler->send($chat_box_message);


?>